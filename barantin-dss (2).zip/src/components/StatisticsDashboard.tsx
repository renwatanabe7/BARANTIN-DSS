import React, { useEffect, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line 
} from 'recharts';
import { BarChart3, PieChart as PieChartIcon, TrendingUp, MapPin, Activity } from 'lucide-react';

interface HistoryEntry {
  timestamp: string;
  scientific_name: string;
  quarantine_status: string;
  risk_level: string;
  region: string;
}

interface StatisticsDashboardProps {
  t: any;
}

const COLORS = ['#059669', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6', '#ec4899'];

// Data Statis berdasarkan Kepkaban No. 571 Tahun 2025
const KEPKABAN_STATS = {
  total_pests: 1248,
  by_status: [
    { name: 'OPTK A1', value: 842 },
    { name: 'OPTK A2', value: 315 },
    { name: 'OPT', value: 91 }
  ],
  by_region: [
    { name: 'Sumatera', count: 142, value: 142 },
    { name: 'Jawa', count: 186, value: 186 },
    { name: 'Kalimantan', count: 98, value: 98 },
    { name: 'Sulawesi', count: 112, value: 112 },
    { name: 'Nusa Tenggara', count: 76, value: 76 },
    { name: 'Maluku', count: 64, value: 64 },
    { name: 'Papua', count: 82, value: 82 }
  ],
  by_category: [
    { name: 'Serangga', count: 412 },
    { name: 'Bakteri', count: 156 },
    { name: 'Cendawan', count: 284 },
    { name: 'Virus', count: 198 },
    { name: 'Nematoda', count: 112 },
    { name: 'Gulma', count: 86 }
  ]
};

const IndonesiaMap = ({ data }: { data: any[] }) => {
  // Further refined paths to match the provided silhouette image more closely
  const regions = [
    { 
      id: 'Sumatera', 
      name: 'Sumatera', 
      path: 'M40,60 L85,50 L115,85 L145,145 L275,275 L255,295 L195,285 L45,135 Z', 
      color: '#059669' 
    },
    { 
      id: 'Kalimantan', 
      name: 'Kalimantan', 
      path: 'M335,95 L395,85 L475,135 L505,235 L475,285 L375,285 L335,235 Z', 
      color: '#3b82f6' 
    },
    { 
      id: 'Jawa', 
      name: 'Jawa', 
      path: 'M265,315 L315,325 L365,335 L465,345 L455,360 L365,355 L265,335 Z', 
      color: '#f59e0b' 
    },
    { 
      id: 'Sulawesi', 
      name: 'Sulawesi', 
      path: 'M545,155 L585,145 L595,185 L635,185 L615,235 L625,285 L585,285 L575,235 L545,235 Z', 
      color: '#ef4444' 
    },
    { 
      id: 'Nusa Tenggara', 
      name: 'Nusa Tenggara', 
      path: 'M485,355 L525,360 L565,365 L605,370 L645,375 L645,385 L565,380 L485,370 Z', 
      color: '#8b5cf6' 
    },
    { 
      id: 'Maluku', 
      name: 'Maluku', 
      path: 'M685,205 L725,210 L720,245 L690,255 Z M695,275 L715,280 L705,295 Z', 
      color: '#ec4899' 
    },
    { 
      id: 'Papua', 
      name: 'Papua', 
      path: 'M805,185 L895,175 L1015,215 L1015,385 L895,385 L805,285 Z', 
      color: '#06b6d4' 
    },
  ];

  return (
    <div className="w-full h-full flex flex-col items-center justify-center">
      <div className="relative w-full aspect-[2.5/1] max-h-[400px] bg-blue-50/30 rounded-2xl border border-blue-100/50 p-4">
        <svg viewBox="0 0 1100 450" className="w-full h-full drop-shadow-md">
          <rect width="1100" height="450" fill="transparent" />
          
          {regions.map((reg) => {
            const regionData = data.find(d => d.name === reg.name);
            return (
              <g key={reg.id} className="group transition-transform hover:scale-[1.01] cursor-default">
                <path
                  d={reg.path}
                  fill={reg.color}
                  className="transition-all duration-300 group-hover:brightness-110"
                  stroke="#fff"
                  strokeWidth="1.5"
                  strokeLinejoin="round"
                />
                <circle
                  cx={
                    reg.id === 'Sumatera' ? 140 : 
                    reg.id === 'Kalimantan' ? 420 : 
                    reg.id === 'Jawa' ? 365 : 
                    reg.id === 'Sulawesi' ? 585 : 
                    reg.id === 'Papua' ? 915 : 
                    reg.id === 'Maluku' ? 705 : 565
                  }
                  cy={
                    reg.id === 'Jawa' ? 335 : 
                    reg.id === 'Nusa Tenggara' ? 370 : 
                    reg.id === 'Sumatera' ? 170 : 210
                  }
                  r="20"
                  fill="white"
                  fillOpacity="0.9"
                  className="drop-shadow-sm"
                />
                <text
                  x={
                    reg.id === 'Sumatera' ? 140 : 
                    reg.id === 'Kalimantan' ? 420 : 
                    reg.id === 'Jawa' ? 365 : 
                    reg.id === 'Sulawesi' ? 585 : 
                    reg.id === 'Papua' ? 915 : 
                    reg.id === 'Maluku' ? 705 : 565
                  }
                  y={
                    reg.id === 'Jawa' ? 335 : 
                    reg.id === 'Nusa Tenggara' ? 370 : 
                    reg.id === 'Sumatera' ? 170 : 210
                  }
                  fill={reg.color}
                  textAnchor="middle"
                  dominantBaseline="central"
                  className="text-[24px] font-black pointer-events-none select-none"
                >
                  {regionData?.count || 0}
                </text>
                <title>{`${reg.name}: ${regionData?.count || 0} OPTK`}</title>
              </g>
            );
          })}
        </svg>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 mt-8 w-full">
        {regions.map((reg) => (
          <div key={reg.id} className="flex items-center gap-2 bg-white p-2.5 rounded-xl border border-slate-100 shadow-sm">
            <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: reg.color }} />
            <span className="text-[12px] font-bold text-slate-600 truncate">{reg.name}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function StatisticsDashboard({ t }: StatisticsDashboardProps) {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchHistory = async () => {
      try {
        const response = await fetch('/api/history');
        if (response.ok) {
          const data = await response.json();
          setHistory(data);
        }
      } catch (error) {
        console.error('Failed to fetch history:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchHistory();
  }, []);

  const renderCustomizedLabel = ({ cx, cy, midAngle, innerRadius, outerRadius, percent }: any) => {
    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * (Math.PI / 180));
    const y = cy + radius * Math.sin(-midAngle * (Math.PI / 180));

    return (
      <text 
        x={x} 
        y={y} 
        fill="white" 
        textAnchor="middle" 
        dominantBaseline="central" 
        className="text-[16px] font-black drop-shadow-md"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-20">
        <Activity className="w-8 h-8 text-emerald-600 animate-spin" />
      </div>
    );
  }

  // Trend over time (by day) - Still use history for trend as it's app usage
  const trendCounts = history.reduce((acc: any, entry) => {
    const date = new Date(entry.timestamp).toLocaleDateString();
    acc[date] = (acc[date] || 0) + 1;
    return acc;
  }, {});

  const trendData = Object.keys(trendCounts).map(date => ({
    date,
    count: trendCounts[date]
  })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-slate-900 flex items-center justify-center gap-3">
          <BarChart3 className="w-8 h-8 text-emerald-600" />
          {t.statsTitle}
        </h2>
        <p className="text-slate-500">{t.statsSubtitle}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center text-center">
          <Activity className="w-10 h-10 text-emerald-600 mb-2" />
          <span className="text-4xl font-bold text-slate-900">{KEPKABAN_STATS.total_pests}</span>
          <span className="text-sm text-slate-500 uppercase tracking-wider font-medium">{t.totalIdentifications}</span>
        </div>
        
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center text-center">
          <PieChartIcon className="w-10 h-10 text-blue-600 mb-2" />
          <span className="text-4xl font-bold text-slate-900">{KEPKABAN_STATS.by_status.length}</span>
          <span className="text-sm text-slate-500 uppercase tracking-wider font-medium">{t.quarantineStatus}</span>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center justify-center text-center">
          <MapPin className="w-10 h-10 text-orange-600 mb-2" />
          <span className="text-4xl font-bold text-slate-900">{KEPKABAN_STATS.by_region.length}</span>
          <span className="text-sm text-slate-500 uppercase tracking-wider font-medium">{t.region}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Pie Chart: Quarantine Status */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <PieChartIcon className="w-5 h-5 text-emerald-600" />
            {t.frequencyByStatus}
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={KEPKABAN_STATS.by_status}
                  cx="40%"
                  cy="50%"
                  labelLine={false}
                  label={renderCustomizedLabel}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {KEPKABAN_STATS.by_status.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend layout="vertical" align="right" verticalAlign="middle" />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Map: Regional Distribution */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 lg:col-span-2">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-600" />
            {t.distributionByRegion}
          </h3>
          <div className="w-full">
            <IndonesiaMap data={KEPKABAN_STATS.by_region} />
          </div>
        </div>

        {/* Bar Chart: Frequency by Category */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 lg:col-span-2">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <Activity className="w-5 h-5 text-emerald-600" />
            {t.frequencyByRegion}
          </h3>
          <div className="h-[400px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={KEPKABAN_STATS.by_category} margin={{ bottom: 60, left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 10 }} 
                  interval={0}
                  angle={-45}
                  textAnchor="end"
                />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  cursor={{ fill: '#f8fafc' }}
                />
                <Bar dataKey="count" radius={[4, 4, 0, 0]} barSize={40}>
                  {KEPKABAN_STATS.by_category.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          {/* Custom Legend for Categories at the bottom */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mt-4">
            {KEPKABAN_STATS.by_category.map((entry, index) => (
              <div key={index} className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-100">
                <div className="w-3 h-3 rounded-full shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                <span className="text-[12px] font-bold text-slate-600 truncate">{entry.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Line Chart: Trend Over Time (App Usage) */}
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 lg:col-span-2">
          <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
            {t.trendOverTime}
          </h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="date" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{ fill: '#64748b', fontSize: 12 }} 
                />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#059669" 
                  strokeWidth={3} 
                  dot={{ r: 6, fill: '#059669', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 8 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
