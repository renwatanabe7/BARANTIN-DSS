import React from 'react';
import { BookOpen, ShieldCheck, History } from 'lucide-react';

const historyData = [
  {
    title: "Awal Mula Karantina",
    description: "Dimulai dengan penerapan ordonansi yang melarang masuknya tanaman dan biji kopi dari Sri Lanka untuk melindungi kebun kopi dari serangan penyakit karat daun kopi (Hemileia vastatrix)."
  },
  {
    title: "Pembentukan Balai Penyelidikan Penyakit Tanaman dan Budi Daya",
    description: "Pada 1914, Balai Penyelidikan Penyakit Tanaman dan Budi Daya secara resmi dibentuk untuk mengawasi impor buah-buahan segar. Balai ini merupakan cikal bakal kelembagaan karantina. Di sisi lain, karantina hewan juga mulai diatur untuk mencegah penyebaran penyakit hewan menular strategis."
  },
  {
    title: "Integrasi Karantina Tumbuhan dan Hewan",
    description: "Karantina tumbuhan dan karantina hewan diintegrasikan, di bawah koordinasi Menteri Pertanian. Sementara itu, karantina ikan berkembang sebagai bidang tersendiri."
  },
  {
    title: "Penguatan Regulasi (1992)",
    description: "Tahun 1992, Presiden Republik Indonesia menetapkan Undang-Undang Nomor 16 Tahun 1992 tentang Karantina Hewan, Ikan, dan Tumbuhan."
  },
  {
    title: "Pusat Karantina Pertanian (1994)",
    description: "Tahun 1994, unsur karantina hewan, ikan, dan tumbuhan diintegrasikan dalam Pusat Karantina Pertanian."
  },
  {
    title: "Kelembagaan Nasional",
    description: "Dibentuk Badan Karantina Pertanian sebagai unit eselon I di Departemen Pertanian. Pada tahun yang sama, karantina ikan diserahterimakan ke Departemen Kelautan dan Perikanan."
  },
  {
    title: "Perluasan Mandat Karantina (2019)",
    description: "Terbitnya Undang-Undang Nomor 21 Tahun 2019 tentang Karantina Hewan, Ikan, dan Tumbuhan memperluas kewenangan karantina. Tidak hanya mencegah masuk dan tersebarnya hama penyakit, tetapi juga mencakup pengawasan keamanan dan mutu pangan serta pakan, produk rekayasa genetik, sumber daya genetik, agens hayati, jenis asing invasif, hingga tumbuhan dan satwa liar maupun langka."
  },
  {
    title: "Badan Karantina Indonesia (Barantin)",
    description: "Fungsi karantina hewan, karantina ikan, dan karantina tumbuhan kembali terintegrasi dalam instansi Badan Karantina Indonesia (Barantin). Hal ini didukung oleh terbitnya Peraturan Presiden Nomor 45 Tahun 2023."
  }
];

const HistoryPage = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="flex items-center gap-4 mb-12">
        <div className="p-4 bg-emerald-100 text-emerald-700 rounded-2xl">
          <History size={32} />
        </div>
        <div>
          <h1 className="text-3xl font-bold text-slate-800">Sejarah Perkarantinaan di Indonesia</h1>
          <p className="text-slate-500">Perjalanan panjang perlindungan sumber daya alam hayati Indonesia.</p>
        </div>
      </div>

      <div className="relative border-l-2 border-emerald-200 ml-6 space-y-12">
        {historyData.map((item, index) => (
          <div key={index} className="relative pl-8">
            <div className="absolute -left-[9px] top-0 w-4 h-4 bg-emerald-500 rounded-full border-4 border-white shadow-sm" />
            <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
              <h2 className="text-lg font-bold text-slate-800 mb-2 flex items-center gap-2">
                <ShieldCheck className="text-emerald-600" size={20} />
                {item.title}
              </h2>
              <p className="text-slate-600 leading-relaxed">{item.description}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default HistoryPage;
