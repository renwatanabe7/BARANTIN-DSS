package com.barantin.dss;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
