# Panduan Deployment BARANTIN DSS

Dokumen ini berisi panduan lengkap untuk melakukan deployment aplikasi BARANTIN DSS, baik sebagai **Website** maupun sebagai **Aplikasi Android (APK)**.

---

## 1. Deployment Website (Vercel / Render / VPS)

Aplikasi ini menggunakan arsitektur Full-Stack (React/Vite di Frontend, Express.js di Backend). Oleh karena itu, platform terbaik untuk deployment adalah layanan yang mendukung Node.js seperti **Render**, **Railway**, atau **VPS**.

### Langkah Deployment di Render / Railway:
1. Buat akun di [Render.com](https://render.com) atau [Railway.app](https://railway.app).
2. Hubungkan repository GitHub Anda yang berisi kode aplikasi ini.
3. Buat **Web Service** baru.
4. Konfigurasi Build & Run:
   - **Build Command:** `npm install && npm run build`
   - **Start Command:** `npm start`
5. Tambahkan **Environment Variables** (Sangat Penting):
   - `GEMINI_API_KEY`: Masukkan API Key Gemini Anda.
6. Klik **Deploy**. Aplikasi web Anda akan langsung dapat diakses melalui URL yang diberikan.

---

## 2. Generate APK Android di Android Studio

Aplikasi ini menggunakan **Capacitor** untuk membungkus website menjadi aplikasi Android native.

### Persiapan Awal (Hanya dilakukan sekali):
1. Pastikan Anda telah menginstal **Android Studio** di komputer Anda.
2. Pastikan Anda telah menginstal Node.js.
3. Buka terminal di folder proyek ini, lalu jalankan perintah berikut untuk menginstal dependensi:
   ```bash
   npm install
   ```

### Langkah Build APK:
1. **Build Frontend & Sinkronisasi ke Android:**
   Jalankan perintah berikut di terminal untuk mem-build kode web terbaru dan menyinkronkannya ke folder Android:
   ```bash
   npm run build:android
   ```
   *(Perintah ini akan menjalankan `vite build` lalu `npx cap sync android`)*

2. **Buka Proyek di Android Studio:**
   Jalankan perintah berikut untuk membuka proyek Android secara otomatis di Android Studio:
   ```bash
   npm run open:android
   ```
   *(Jika perintah ini gagal, buka Android Studio secara manual, lalu pilih **Open**, dan arahkan ke folder `android` di dalam proyek ini).*

3. **Tunggu Proses Gradle Sync:**
   Saat Android Studio terbuka, tunggu beberapa saat hingga proses *Gradle Sync* di pojok kanan bawah selesai.

4. **Generate APK / App Bundle:**
   - Di menu atas Android Studio, klik **Build** > **Build Bundle(s) / APK(s)** > **Build APK(s)**.
   - Tunggu proses build selesai (biasanya memakan waktu 1-3 menit).
   - Setelah selesai, akan muncul notifikasi pop-up di pojok kanan bawah. Klik tulisan **locate** berwarna biru pada notifikasi tersebut.
   - Anda akan diarahkan ke folder tempat file `app-debug.apk` berada (biasanya di `android/app/build/outputs/apk/debug/`).
   - File APK ini sudah siap untuk diinstal di HP Android Anda.

### Catatan Penting untuk Android:
Karena aplikasi Android berjalan secara lokal di perangkat pengguna, ia tidak memiliki backend server sendiri. Oleh karena itu, aplikasi Android perlu berkomunikasi dengan backend website yang sudah Anda deploy di langkah 1.

Pastikan URL backend di file `src/App.tsx` (pada fungsi `getApiUrl`) sudah mengarah ke URL website Anda yang sudah di-deploy:
```typescript
const getApiUrl = () => {
  if (Capacitor.isNativePlatform()) {
    // GANTI URL INI DENGAN URL WEBSITE ANDA YANG SUDAH DI-DEPLOY (misal: https://barantin-dss.onrender.com)
    return 'https://ais-pre-oa4vo6s4cqlc6deoezomlg-359100989091.asia-east1.run.app';
  }
  return '';
};
```
Jika Anda mengubah URL ini, pastikan untuk menjalankan kembali `npm run build:android` sebelum men-generate APK baru di Android Studio.
