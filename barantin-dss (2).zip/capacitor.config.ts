import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.barantin.dss',
  appName: 'Insect Detector',
  webDir: 'dist'
};

export default config;
